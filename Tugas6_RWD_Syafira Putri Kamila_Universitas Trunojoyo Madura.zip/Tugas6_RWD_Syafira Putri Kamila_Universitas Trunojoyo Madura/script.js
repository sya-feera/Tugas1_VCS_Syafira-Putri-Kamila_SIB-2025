$(document).ready(function() {
    // Initialize the main DataTable
    const mainTable = $('#dataPegawai').DataTable({
        dom: '<"dt-buttons"B><"clear">lf<"table-responsive"t>ip',
        buttons: [
            {
                extend: 'copy',
                text: 'Copy',
                className: 'btn-pink'
            },
            {
                extend: 'csv',
                text: 'CSV',
                className: 'btn-pink'
            },
            {
                extend: 'excel',
                text: 'Excel',
                className: 'btn-pink'
            },
            {
                extend: 'pdf',
                text: 'PDF',
                className: 'btn-pink'
            },
            {
                extend: 'print',
                text: 'Print',
                className: 'btn-pink'
            },
        ],
        language: {
            info: "Showing _START_ to _END_ of _TOTAL_ entries",
            paginate: {
                first: "«",
                previous: "‹",
                next: "›",
                last: "»"
            }
        },
        pageLength: 10,
        order: [[0, 'asc']], // Sort by first column (Name) in ascending order
        responsive: true
    });
});